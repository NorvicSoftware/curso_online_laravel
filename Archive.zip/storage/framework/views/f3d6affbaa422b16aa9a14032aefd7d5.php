<?php $__env->startSection('content'); ?>
    <h2>Listado de Profesores</h2>
    <table>
        <tr>
            <th>Nombre y Apellido</th>
            <th>Profesión</th>
            <th>Grado Academico</th>
            <th>Teléfono</th>
        </tr>
        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($profesor->nombre_apellido); ?></td>
                <td><?php echo e($profesor->profesion); ?></td>
                <td><?php echo e($profesor->grado_academico); ?></td>
                <td><?php echo e($profesor->telefono); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/victorpenia/Norvic/cursos-online/resources/views/profesores/index.blade.php ENDPATH**/ ?>